#' Numeric Differentiation
#' @name genaDiff
#' @description Numeric estimation of the gradient and Hessian.
#' @param fn function for which gradient or Hessian should be calculated.
#' @param gr gradient function of \code{fn}.
#' @param par point (parameters' value) at which \code{fn} should be 
#' differentiated.
#' @param eps numeric vector representing increment of the \code{par}. 
#' So \code{eps[i]} represents increment of \code{par[i]}. If \code{eps} is
#' a constant then all increments are the same.
#' @param method numeric differentiation method: "central-difference" or
#' "forward-difference".
#' @param fn_args list containing arguments of \code{fn} except \code{par}.
#' @param gr_args list containing arguments of \code{gr} except \code{par}.
#' @details It is possible to substantially improve numeric Hessian accuracy 
#' by using analytical gradient \code{gr}. If both \code{fn} and \code{gr}
#' are provided then only \code{gr} will be used. If only \code{fn} is provided 
#' for \code{gena.hessian} then \code{eps} will be transformed to 
#' \code{sqrt(eps)} for numeric stability purposes.
#'
#' @return Function \code{gena.grad} returns a vector that is a gradient of 
#' \code{fn} at point \code{par} calculated via \code{method} numeric 
#' differentiation approach using increment \code{eps}.
#' 
#' Function \code{gena.hessian} returns a matrix that is a Hessian of 
#' \code{fn} at point \code{par}.
#' @examples 
#' # Consider the following function
#' fn <- function(par, a = 1, b = 2)
#' {
#'   val <- par[1] * par[2] - a * par[1] ^ 2 - b * par[2] ^ 2
#' }
#' 
#' # Calculate the gradient at point (2, 5) respect to 'par' 
#' # when 'a = 1' and 'b = 1'
#' par <- c(2, 5)
#' fn_args = list(a = 1, b = 1)
#' gena.grad(fn = fn, par = par, fn_args = fn_args)
#' 
#' # Calculate Hessian at the same point
#' gena.hessian(fn = fn, par = par, fn_args = fn_args)
#' 
#' # Repeat calculation of the Hessian using analytical gradient
#' gr <- function(par, a = 1, b = 2)
#' {
#'   val <- c(par[2] - 2 * a * par[1],
#'            par[1] - 2 * b * par[2])
#' }
#' gena.hessian(gr = gr, par = par, gr_args = fn_args)
#' 
#' @rdname genaDiff
#' @export
gena.grad <- function(fn, par, 
                      eps = sqrt(.Machine$double.eps) * abs(par),
                      method = "central-difference",
                      fn_args = NULL)
{
  n_par <- length(par)
  
  if(length(eps) == 1)
  {
    eps <- rep(eps, n_par)
  }
    
  par_plus <- par
  par_minus <- par
    
  val <- rep(0, n_par)

  for(i in 1:n_par)
  {
    if (method == "central-difference")
    {
      par_plus[i] <- par[i] + eps[i]
    }

    par_minus[i] <- par[i] - eps[i]
      
    fn_args$par <- par_plus
    fn_plus <- do.call(fn, fn_args)
   
    fn_args$par <- par_minus
    fn_minus <- do.call(fn, fn_args)
      
    par_plus <- par
    par_minus <- par
       
    if (method == "central-difference")
    {
      val[i] <- (fn_plus - fn_minus) / (2 * eps[i])
    }
    if (method == "forward-difference")
    {
      val[i] <- (fn_plus - fn_minus) / eps[i]
    }
  }
  
  return(val)
}

#' @rdname genaDiff
#' @export
gena.hessian <- function(fn = NULL, gr = NULL, 
                         par, eps = sqrt(.Machine$double.eps) * abs(par), 
                         fn_args = NULL, gr_args = NULL)
{
  n_par <- length(par)
  
  if (is.null(gr))
  {
    eps <- sqrt(eps)
  }
  
  if(length(eps) == 1)
  {
    eps <- rep(eps, n_par)
  }
  
  par_plus <- par
  par_minus <- par
  
  val <- matrix(0, n_par, n_par)
  
  # With analytical gradient
  if (!is.null(gr))
  {
    for(i in 1:n_par)
    {
      par_plus[i] <- par[i] + eps[i]
      par_minus[i] <- par[i] - eps[i]
        
      gr_args$par <- par_plus
      gr_plus <- do.call(gr, gr_args)
        
      gr_args$par <- par_minus
      gr_minus <- do.call(gr, gr_args)
        
      par_plus <- par
      par_minus <- par
        
      val[i, ] <- (gr_plus - gr_minus) / (2 * eps[i])
    }
    
    for (i in 1:n_par)
    {
      for (j in 1:i)
      {
        if (i != j)
        {
          val[i, j] <- (val[i, j] + val[j, i]) / 2
          val[j, i] <- val[i, j]
        }
      }
    }
  }
  # Without analytical gradient
  else
  {
    fn_args$par <- par
    fn_0 <- do.call(fn, fn_args)
    
    fn_plus <- rep(NA, n_par)
    for (i in 1:n_par)
    {
      par_plus[i] <- par[i] + eps[i]
      fn_args$par <- par_plus
      fn_plus[i] <- do.call(fn, fn_args)
      par_plus[i] <- par[i]
    }
    
    par_ij <- par
    for (i in 1:n_par)
    {
      par_ij[i] <- par[i] + eps[i]
      for (j in 1:i)
      {
        par_ij[j] <- par_ij[j] + eps[j]
        fn_args$par <- par_ij
        
        fn_ij <- do.call(fn, fn_args)
        val[i, j] <- (fn_ij - fn_plus[i] - fn_plus[j] + fn_0) / 
                     (eps[i] * eps[j])
        val[j, i] <- val[i, j]
          
        par_ij[j] <- par[j]
      }
      par_ij[i] <- par[i]
    }
  }
  
  return(val)
}

# gena.lineSearch <- function(fn, gr = NULL, 
#                             fn.val, gr.val, 
#                             par, 
#                             p, a = 1,
#                             tau = 0.5, c = 0.5,
#                             maxiter = 100, 
#                             fn.args = NULL, gr.args = NULL)
# {
#   # Estimate a special value for Armijo condition
#   m <- sum(gr.val * p)
#   
#   # Initialize variables to store parameters and
#   # update parameters information from previous step
#   par_old <- par
#   a_old <- a
#   
#   # A list to return
#   return.list <- list(a = a,
#                       par = par)
#   
#   # If TRUE then update parameter will be increasing.
#   # Otherwise it will be decreasing.
#   is_increase = FALSE
# 
#   for (i in 1:maxiter)
#   {
#     return.list$iter <- i
#     
#     fn.args$par <- par + a * p                             # update parameter
#     
#     fn.val.new <- do.call(fn, fn.args)                     # estimate function value
#     cond.val <- fn.val.new - fn.val - (a * c * m)          # estimate Armijo condition
#                                                            # related value
# 
#     if (cond.val >= 0)                                     # check whether Armijo
#     {                                                      # condition is satisfied
#       if (i == 1)                                          # decide whether to increase
#       {                                                    # or decrease update parameter
#         is_increase <- TRUE
#       }
# 
#       if (!is_increase)                                    # if the parameter should
#       {                                                    # be decreased
#         return.list$par <- fn.args$par
#         return.list$a <- a
#         return(return.list)
#       }
#     }
#     
#     if ((cond.val < 0) & is_increase)                      # if Armijo condition is 
#                                                            # not satisfied but
#     {                                                      # we need to increase
#       return.list$par <- par_old                           # the update parameter
#       return.list$a <- a_old
#       return(return.list)
#     }
#     
#     par_old <- fn.args$par
#     a_old <- a
#     
#     a <- ifelse(is_increase, a / tau, a * tau)
#   }
#   
#   return(return.list)
# }
# 
# gena.gd <- function(fn,                                    # function to optimize
#                     gr = NULL,                             # gradient of the function
#                     x0,                                    # initial point
#                     iter = 1000,                           # the number of iterations
#                     reltol = 1e-10,                        # relative tolerance
#                     lr = 1,                                # learning rate
#                     type = "GD",                           # optimization type
#                     momentum = 0.9,
#                     ...)                                   # additional arguments for fn and gr  
# {
#   dots <- list(...)
#   
#   # Get the number of estimated parameters
#   n_x <- length(x0)
#   
#   # Initialize the matrix to store the
#   # points for each iteration
#   x <- matrix(NA, 
#               nrow = iter,
#               ncol = length(x0))
#   x[1, ] <- x0
#   
#   # Initialize variable to store gradient
#   # information
#   gr.val <- matrix(NA, nrow = iter, ncol = n_x)
# 
#   # Start the algorithm
#   for (i in 2:iter)
#   {
#     # Estimate the function value
#     dots$par <- x[i - 1, ]
#     fn.val <- do.call(fn, dots)
# 
#     # Estimate the analytical gradient if it has
#     # been provided by the user. Otherwise apply
#     # numeric optimization routine.
#     if(is.null(gr))
#     {
#       gr.val[i, ] <- gena.grad(fn, x[i - 1, ], fn.args = dots)
#     } else {
#       dots$par <- x[i - 1, ]
#       gr.val[i, ] <- do.call(gr, dots)
#     }
# 
#     # Determine the direction
#     dir <- gr.val[i, ]
#     if (i >= 3)
#     {
#      G <- t(gr.val[3:(i - 1), ]) %*% gr.val[3:(i - 1), ]
#      dir <- dir / sqrt(diag(G) + (1e-8))
#     }
#     # Perform the line search
#     ls.result <- gena.lineSearch(fn = fn, gr = gr, 
#                                  fn.val = fn.val, gr.val = gr.val[i, ],
#                                  par = x[i - 1, ], p = dir, a = lr,
#                                  fn.args = dots)
#     x[i, ] <- ls.result$par
#     lr <- ls.result$a
#     print(lr)
#     print(ls.result$iter)
#     
#     # Check whether termination conditions
#     # are satisfied
#     if (all(abs((x[i - 1, ] - x[i, ]) /
#                 x[i - 1, ]) < reltol))
#     {
#       x <- x[1:i, ]
#       break
#     }
#     
#     cat(paste0("iter-", i, ": ", fn.val, "\n"))
#   }
#   
#   # Get the final point
#   solution <- tail(x, 1)
#   
#   return_list <- list("points" = x,
#                       "solution" = solution,
#                       "fn_value" = fn(solution,    
#                                       ... = ...),
#                       "fn_grad" = gr.val)
#   
#   return(return_list)
# }